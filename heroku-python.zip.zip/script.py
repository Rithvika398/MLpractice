while True:
	print("I am working!")
